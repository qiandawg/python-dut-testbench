MotorTestTags = ["Start",     #0
                 "Stop",      #1 
                 "EMGC",      #2
                 "OVLD",      #3
                 "Coil"       #4


                 ]


CalibTags = {
             }  

MotorTestpath=    ["0:Objects", "2:FactoryTalkLinxGateway", "4:PLC",
                                   "6:Online" , "var"]


